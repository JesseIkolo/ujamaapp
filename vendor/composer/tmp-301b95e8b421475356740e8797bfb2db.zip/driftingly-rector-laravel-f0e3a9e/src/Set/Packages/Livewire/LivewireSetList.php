<?php

namespace RectorLaravel\Set\Packages\Livewire;

final class LivewireSetList
{
    /**
     * @var string
     */
    public const LIVEWIRE_30 = __DIR__ . '/../../../../config/sets/packages/livewire/livewire-30.php';
}
