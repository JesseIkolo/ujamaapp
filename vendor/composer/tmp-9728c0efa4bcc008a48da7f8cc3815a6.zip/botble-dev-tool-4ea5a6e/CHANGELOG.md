# Changelog

All notable changes to `botble/dev-tool` will be documented in this file.

## 1.0.2 - 2024-03-14

- Feat: Setting make commands by @dat-archielite in #1
- Improve commands by @dat-archielite in #2
- Feat: update new syntax dev tool by @quoc-archielite in #3
- Improve: support run on Windows by @dinhquochan in #4
- Improve: able to create a child theme by @dinhquochan in #5
- Improve: theme stubs by @dinhquochan in #6

## 1.0.1 - 2023-10-30

- Update CommandServiceProvider.php

## 1.0.0 - 2023-08-10

- First release.
